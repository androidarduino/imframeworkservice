/***************************************************************************
 *   Copyright (C) 2008 by Keith Rusler   *
 *   xeckosx@live.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "MSNCrypto.h"

struct MSNPMSNG {
	unsigned long headerSize;
	unsigned long cryptMode;
	unsigned long cipherType;
	unsigned long hashType;
	unsigned long ivLength;
	unsigned long hashLength;
	unsigned long cipherLength;

	unsigned char ivBytes[8];
	unsigned char hashBytes[20];
	unsigned char cipherBytes[72];
};

MSNCrypto::MSNCrypto ( QObject *parent )
		: QObject ( parent )
{
}

QString
MSNCrypto::mbiEncrypt ( QString ssoKey, QString nonce )
{
	QString magic1 = "WS-SecureConversationSESSION KEY HASH";
	QString magic2 = "WS-SecureConversationSESSION KEY ENCRYPTION";
	// create the key.
	QByteArray key1, key2, key3;
	// create the hashes needed.
	QByteArray hash, des3hash;
	// create the base64 object.
	QCA::Base64 base64;

	// decode the ssoKey and assign it.
	key1 = base64.decode ( ssoKey.toLatin1() ).toByteArray();
	// create the second key using the first key and magic1.
	key2 = deriveKey ( key1, magic1 );
	// create the third key using the first key and magic2.
	key3 = deriveKey ( key1, magic2 );

	// create a new HMAC Sha1 hash using the second key and hash the nonce.
	hash = createHMACSha1 ( key2, nonce );

	// the windows api always pads using \x08 so we pad 8 bytes.
	nonce += QByteArray ( 8, '\x08' );

	// create the IV key.
	QCA::InitializationVector iv;
	// create the Triple Des object using key3 with the new padded nonce.
	// IV is created inside of the function and passed back out.
	des3hash = createTripleDes ( key3, nonce, iv );

	// create the required 128 byte padded struct.
	// see the url for more information.
	// http://msnpiki.msnfanatic.com/index.php/MSNP15:SSO
	MSNPMSNG blob;
	// create the head size of 28.
	blob.headerSize = 28;
	// CRYPT_MODE_CBC
	blob.cryptMode = 1;
	// Cipher Type (TripleDes)
	blob.cipherType = 0x6603;
	// Hash Type (Sha1)
	blob.hashType = 0x8004;
	// Length of the IV (8 Random Bytes)
	blob.ivLength = 8;
	// Length of the HMAC hash
	blob.hashLength = 20;
	// Cipher Length
	blob.cipherLength = 72;

	// copy the IV Bytes.
	for ( qint32 i = 0; i < iv.size(); ++i ) {
		blob.ivBytes[i] = iv[i];
	}

	// copy the Hash values.
	for ( qint32 i = 0; i < hash.size(); ++i ) {
		blob.hashBytes[i] = hash[i];
	}

	// copy the Cipher values.
	for ( qint32 i = 0; i < des3hash.size(); ++i ) {
		blob.cipherBytes[i] = des3hash[i];
	}

	// create a byte array and assign the reference of the MSNPMSNG struct with
	// a 128 byte limit.
	QByteArray blobs ( reinterpret_cast<const char*> ( &blob ), 128 );
	
	// return a base64 encoded of the array.
	return base64.encode ( blobs ).toByteArray();
}

QByteArray
MSNCrypto::deriveKey ( QString ssoKey, QString magic )
{
	// create the four hashes needed for the implementation.
	QByteArray hash1, hash2, hash3, hash4, temp;

	// append the magic string.
	temp.append ( magic.toLatin1() );
	// create the HMAC Sha1 hash and assign it.
	hash1 = createHMACSha1 ( ssoKey.toLatin1(), temp );
	// clear the temp array.
	temp.clear();

	// append the first hash with the magic string.
	temp.append ( hash1 + magic.toLatin1() );
	// create the HMAC Sha1 hash and assign it.
	hash2 = createHMACSha1 ( ssoKey.toLatin1(), temp );
	// clear the tmep array.
	temp.clear();

	// append the first hash.
	temp.append ( hash1 );
	// create the HMAC Sha1 hash and assign it.
	hash3 = createHMACSha1 ( ssoKey.toLatin1(), temp );
	// clear the array.
	temp.clear();

	// assign the third hash with the magic string.
	temp.append ( hash3 + magic.toLatin1() );
	// create the HMAC Sha1 hash and assign it.
	hash4 = createHMACSha1 ( ssoKey.toLatin1(), temp );
	// clear the temp array.
	temp.clear();

	// return the second hash with the first four bytes of the fourth hash.
	return ( hash2 + hash4.left ( 4 ) );
}

QByteArray
MSNCrypto::createHMACSha1 ( QByteArray key, QString secret )
{
	// check for HMAC Sha1 support.
	if ( !QCA::isSupported ( "hmac(sha1)" ) ) {
		qFatal ( "[Error] HMAC Sha1 not supported!" );
	} else {
		// create the HMAC Sha1 object.
		QCA::MessageAuthenticationCode hmac ( "hmac(sha1)", QCA::SecureArray() );
		// create the key using the key parameter.
		QCA::SymmetricKey hmacKey ( key );
		// now assign the new symmetric key so the HMAC Sha1 object uses it.
		hmac.setup ( hmacKey );
		// create a secure array which doesn't allow the array to be seen
		// from outside the program (added security) with the secret.
		QCA::SecureArray magic ( secret.toLatin1() );
		// now we update the secure array with the new hash.
		hmac.update ( magic );
		// create another secure array with the final hash.
		// no more updates to this object in this call is allowed now.
		QCA::SecureArray array = hmac.final();
		// return the new hash array.
		return array.toByteArray();
	}
	// shouldn't be called if the cryptography method is supported.
	return "";
}

QByteArray
MSNCrypto::createTripleDes ( QString key, QString secret, QCA::InitializationVector& iv )
{
	// check for Triple Des with CBC support.
	if ( !QCA::isSupported ( "tripledes-cbc" ) ) {
		qFatal ( "triple des not support" );
	} else {
		// create the key using the key parameter.
		QCA::SymmetricKey desKey ( key.toLatin1() );
		// this is where the IV is offically created.
		QCA::InitializationVector tempIV ( 8 );
		// assign the iv to be passed through the parameter.
		iv = tempIV;
		// create a secure array using the secret parameter.
		QCA::SecureArray data ( secret.toLatin1() );
		// create the TripleDes object.
		QCA::Cipher des3 ( QString ( "tripledes" ),
				   // use the CBC mode.
				   QCA::Cipher::CBC,
				   // we don't need passing.
				   QCA::Cipher::NoPadding,
				   // we are encoding a new hash.
				   QCA::Encode,
				   // use the new key.
				   desKey,
				   // use the new random 8 byte IV.
				   tempIV );
		// cipher however actually uses update with the final hash of it.
		QCA::SecureArray temp = des3.update ( data );
		// we only need to assign final to a byte array if we use padding.
		// since the implentation doesn't use padding we can leave it like this.
		// no more updating the hash is allowed now.
		des3.final();
		// check to make sure the hashing performed right.
		if ( !des3.ok() ) {
			qFatal ( "Triple Des Failed hash" );
		}
		// return the new triple des hash
		return temp.toByteArray();
	}
	// shouldn't be called if the cryptography method is supported.
	return "";
}
