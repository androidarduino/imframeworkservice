/***************************************************************************
 *   Copyright (C) 2008 by Keith Rusler   *
 *   xeckosx@live.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <QtCrypto>
#include <QString>
#include <QDebug>

//! MSN Cryptography class.
class MSNCrypto : public QObject
{
public:
	//! Default constructor.
	/*!
	 * \param parent needed by the parent object class.
	 */
	MSNCrypto ( QObject *parent = NULL );

	//! create the MSNP15 SSO Encryption.
	/*!
	 * \param ssoKey the sso proof key.
	 * \param nonce the nonce key.
	 * \return the sso encryption string.
	 */
	QString mbiEncrypt ( QString ssoKey, QString nonce );

	//! creates the HMAC Sha1 implentation using 4 hashes.
	/*!
	 * \param key Hash object key.
	 * \param secret Hash object needing to be hashed.
	 * \return the HMAC Sha1 hash.
	 */
	QByteArray createHMACSha1 ( QByteArray key, QString secret );
	//! create the Triple Des hash.
	/*!
	 * \param key Hash object key.
	 * \param secret Hash object needing to be hashed.
	 * \param iv (out) the InitializingVector key.
	 */
	QByteArray createTripleDes ( QString key, QString secret, QCA::InitializationVector& iv );

private:
	//! create the derive key used in mbiEncryption.
	/*!
	 * \param ssoKey the sso proof key.
	 * \param magic the magic string key.
	 * \return the hash of the key.
	 */
	QByteArray deriveKey ( QString ssoKey, QString magic );
};
